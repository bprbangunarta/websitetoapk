<?php $__env->startSection('title', 'FAQs'); ?>

<?php $__env->startSection('content'); ?>
<div class="appHeader bg-primary">
    <div class="left"></div>
    <div class="pageTitle">
        <?php echo $__env->yieldContent('title'); ?>
    </div>
    <div class="right"></div>
</div>

<div id="appCapsule">
    <div class="section mt-2 text-center">
        <div class="card">
            <div class="card-body pt-3 pb-3">
                <img src="<?php echo e(asset('assets/img/sample/photo/vector1.png')); ?>" alt="image" class="imaged w-50 ">
                <h2 class="mt-2">Frequently Asked <br> Questions</h2>
            </div>
        </div>
    </div>

    <div class="section inset mt-2">
        <div class="accordion" id="accordionExample1">
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#accordion01">
                        What is Finapp?
                    </button>
                </h2>
                <div id="accordion01" class="accordion-collapse collapse" data-bs-parent="#accordionExample1">
                    <div class="accordion-body">
                        Finapp is HTML mobile template for mobile devices.
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#accordion02">
                        Is Finapp Bootstrap 5 based?
                    </button>
                </h2>
                <div id="accordion02" class="accordion-collapse collapse" data-bs-parent="#accordionExample1">
                    <div class="accordion-body">
                        Yes. Finapp using Bootstrap 5 css framework.
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#accordion03">
                        How can i customize this template?
                    </button>
                </h2>
                <div id="accordion03" class="accordion-collapse collapse" data-bs-parent="#accordionExample1">
                    <div class="accordion-body">
                        Finapp based on HTML, CSS and Vanilla Javascript. That's all. You don't need others. Use
                        your web skills you already known.
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#accordion04">
                        Is this template a PWA?
                    </button>
                </h2>
                <div id="accordion04" class="accordion-collapse collapse" data-bs-parent="#accordionExample1">
                    <div class="accordion-body">
                        Yes, Finapp is a PWA (Progressive Web App) ready. You can add it your mobile device's
                        homescreen and use it like an app.
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#accordion05">
                        How can i buy this?
                    </button>
                </h2>
                <div id="accordion05" class="accordion-collapse collapse" data-bs-parent="#accordionExample1">
                    <div class="accordion-body">
                        You can buy it on <a href="https://themeforest.net/item/finapp-wallet-banking-htms-mobile-template/25738217" target="_blank">Themeforest</a>.
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="section mt-3 mb-3">
        <div class="card bg-primary">
            <div class="card-body text-center">
                <h5 class="card-title">Still have question?</h5>
                <p class="card-text">
                    Feel free to contact us
                </p>
                <a href="#" class="btn btn-success">
                    <ion-icon name="logo-whatsapp"></ion-icon> WhatsApp
                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/zulfame/Projects/!LOCAL/webview/resources/views/interested.blade.php ENDPATH**/ ?>