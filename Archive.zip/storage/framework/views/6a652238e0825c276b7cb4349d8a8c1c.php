<?php $__env->startSection('title', 'Upload File'); ?>

<?php $__env->startSection('content'); ?>
<div class="appHeader bg-primary">
    <div class="left">
        <a href="/" class="headerButton goBack text-white">
            <ion-icon name="chevron-back-outline"></ion-icon>
        </a>
    </div>
    <div class="pageTitle">
        <?php echo $__env->yieldContent('title'); ?>
    </div>
    <div class="right"></div>
</div>

<div id="appCapsule">
    <div class="section mt-2 mb-1">
        <div class="card">
            <div class="card-body">

                <form action="<?php echo e(route('testing.upload.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="custom-file-upload" id="fileUpload1">
                        <input type="file" name="photo" id="fileuploadInput" accept=".png, .jpg, .jpeg">
                        <label for="fileuploadInput">
                            <span>
                                <strong>
                                    <ion-icon name="arrow-up-circle-outline" role="img" class="md hydrated" aria-label="arrow up circle outline"></ion-icon>
                                    <i>Upload Photo</i>
                                </strong>
                            </span>
                        </label>

                    </div>
                    <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="form-group boxed mt-1">
                        <div class="input-wrapper">
                            <label class="label" for="text4b">Upload Document</label>
                            <input type="file" class="form-control" name="file" accept=".pdf, .doc, .docx, .xls, .xlsx, .ppt, .pptx">
                        </div>

                        <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block mt-1" id="btn-submit">Upload</button>
                </form>
            </div>
        </div>
    </div>

    <?php if($testing): ?>
    <?php if($testing->photo || $testing->file): ?>
    <div class="listview-title">Result</div>
    <?php endif; ?>
    <ul class="listview image-listview media inset mb-2">
        <?php if($testing->photo): ?>
        <li>
            <a href="#" class="item" data-bs-toggle="modal" data-bs-target="#actionSheetInset">
                <div class="imageWrapper">
                    <img src="<?php echo e(Storage::url($testing->photo)); ?>" alt="Webview" class="imaged w64">
                </div>
                <div class="in">
                    <div>
                        <?php echo e(Str::after($testing->photo, 'testing/')); ?>

                        <div class="text-muted"><?php echo e($testing->created_at); ?></div>
                    </div>
                </div>
            </a>
        </li>

        <div class="modal fade action-sheet inset" id="actionSheetInset" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Action Sheet Title</h5>
                    </div>
                    <div class="modal-body">
                        <ul class="action-button-list">
                            <li>
                                <a href="<?php echo e(Storage::url($testing->photo)); ?>" class="btn btn-list">
                                    <span>
                                        <ion-icon name="cloud-download-outline"></ion-icon>
                                        Download
                                    </span>
                                </a>
                            </li>

                            <li>
                                <a href="#" class="btn btn-list" data-bs-toggle="modal" data-bs-target="#modalPhoto" data-bs-dismiss="modal">
                                    <span>
                                        <ion-icon name="trash-outline"></ion-icon>
                                        Delete File
                                    </span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade dialogbox" id="modalPhoto" data-bs-backdrop="static" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <form action="<?php echo e(route('testing.upload.update')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="pt-3 text-center">
                            <img src="<?php echo e(Storage::url($testing->photo)); ?>" alt="Webview" class="imaged w48 rounded mb-1">
                        </div>
                        <div class="modal-body mt-2">
                            Are you sure you want to delete the photo file?
                            <input type="hidden" name="photo" value="<?php echo e($testing->photo); ?>">
                        </div>
                        <div class="modal-footer">
                            <div class="btn-inline">
                                <a href="#" class="btn btn-text-secondary" data-bs-dismiss="modal">CANCEL</a>
                                <button type="submit" class="btn btn-text-danger">DELETE</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <?php if($testing->file): ?>
        <li>
            <a href="#" class="item" data-bs-toggle="modal" data-bs-target="#actionSheetInset">
                <div class="imageWrapper">
                    <img src="https://thumbs.dreamstime.com/b/file-folder-icon-flat-style-illustration-vector-web-design-128273206.jpg" alt="Webview" class="imaged w64">
                </div>
                <div class="in">
                    <div>
                        <?php echo e(Str::after($testing->file, 'testing/')); ?>

                        <div class="text-muted"><?php echo e($testing->created_at); ?></div>
                    </div>
                </div>
            </a>
        </li>

        <div class="modal fade action-sheet inset" id="actionSheetInset" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Action Sheet Title</h5>
                    </div>
                    <div class="modal-body">
                        <ul class="action-button-list">
                            <li>
                                <a href="<?php echo e(Storage::url($testing->file)); ?>" class="btn btn-list">
                                    <span>
                                        <ion-icon name="cloud-download-outline"></ion-icon>
                                        Download
                                    </span>
                                </a>
                            </li>

                            <li>
                                <a href="#" class="btn btn-list" data-bs-toggle="modal" data-bs-target="#modalFile" data-bs-dismiss="modal">
                                    <span>
                                        <ion-icon name="trash-outline"></ion-icon>
                                        Delete File
                                    </span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade dialogbox" id="modalFile" data-bs-backdrop="static" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <form action="<?php echo e(route('testing.upload.update')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="pt-3 text-center">
                            <img src="https://thumbs.dreamstime.com/b/file-folder-icon-flat-style-illustration-vector-web-design-128273206.jpg" alt="Webview" class="imaged w48 rounded mb-1">
                        </div>
                        <div class="modal-body mt-2">
                            Are you sure you want to delete the file?
                            <input type="hidden" name="file" value="<?php echo e($testing->file); ?>">
                        </div>
                        <div class="modal-footer">
                            <div class="btn-inline">
                                <a href="#" class="btn btn-text-secondary" data-bs-dismiss="modal">CANCEL</a>
                                <button type="submit" class="btn btn-text-danger">DELETE</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </ul>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const form = document.querySelector('form');
        const submitButton = document.getElementById('btn-submit');

        form.addEventListener('submit', function() {
            submitButton.disabled = true;
            submitButton.textContent = 'Processing';
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/zulfame/Projects/!LOCAL/webview/resources/views/testing/upload.blade.php ENDPATH**/ ?>